ROYAL KSAMIL ANDROID

Ky projekt paketizon prototipin Royal Ksamil si aplikacion Android native WebView.

Build lokal me Android Studio:
1. Hap dosjen RoyalKsamil-Android.
2. Lejo Gradle sync.
3. Build > Build APK(s).
4. APK gjendet te app/build/outputs/apk/debug/app-debug.apk.

Shenim:
Ky paketim përfshin UI/prototipin offline. API-të e versionit full-stack të backup-it kërkojnë backend të hostuar dhe URL publike; për funksionalitet 100% live, WebView duhet të drejtohet te deployment-i i aplikacionit ose backend-i të lidhet me app-in.

--- CLOUD APK BUILD ---
GitHub Actions workflow included at:
.github/workflows/build-apk.yml
Manual build: Actions > Build Royal Ksamil APK > Run workflow.
Output artifact contains RoyalKsamil.apk.
