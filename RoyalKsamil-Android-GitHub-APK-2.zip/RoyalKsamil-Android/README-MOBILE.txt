ROYAL KSAMIL - KRIJO APK NGA TELEFONI ME GITHUB
================================================

Ky projekt eshte pergatitur qe GitHub ta kompiloje automatikisht ne RoyalKsamil.apk.
Nuk ke nevoje per kompjuter ose Android Studio.

HAPAT NGA TELEFONI:

1. Hape https://github.com ne browser dhe hyr/krijo nje llogari.
2. Krijo nje repository te ri, p.sh. RoyalKsamil-Android.
3. Ngarko TE GJITHA skedaret dhe dosjet qe ndodhen brenda kesaj dosjeje.
   E rendesishme: duhet te ngarkohet edhe dosja .github/workflows.
4. Pasi skedaret te jene ne GitHub, hape repository-n.
5. Hape skeden "Actions".
6. Zgjidh "Build Royal Ksamil APK".
7. Shtyp "Run workflow" dhe perseri "Run workflow".
8. Prit derisa procesi te behet me shenje jeshile (zakonisht disa minuta).
9. Hape build-in e perfunduar dhe poshte te "Artifacts" shtyp "RoyalKsamil-APK".
10. Shkarko ZIP-in, hape dhe brenda do te gjesh: RoyalKsamil.apk
11. Shtyp RoyalKsamil.apk ne Samsung dhe zgjidh Install.

Nese Android pyet per leje:
Settings > Install unknown apps > lejo browser-in/File Manager qe perdore.
Pas instalimit mund ta çaktivizosh perseri kete leje.

SHENIM:
Ky build krijon nje APK DEBUG te instalueshme direkt ne telefon, e pershtatshme per testim.
Per publikim ne Google Play duhet nje release i nenshkruar me keystore privat.
