# Royal Ksamil Android

Android WebView shell for https://royalksamil.com/.

## Security model

- Only `royalksamil.com` and `www.royalksamil.com` remain inside the WebView.
- Other HTTP(S) links open externally.
- Camera and location permissions are requested only when the website actually needs them.
- WebView permission requests are denied for untrusted origins.
- Cleartext HTTP traffic and mixed content are disabled.
- Third-party cookies are disabled.
- File-system access from WebView is disabled.

## Build

Requires JDK 17, Android SDK 35 and Gradle 8.11.1.

```bash
gradle assembleRelease
```

GitHub Actions builds pull requests unsigned and signs `main`/manual builds using these repository secrets:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

## Repository cleanup

Do not commit APKs, AABs, ZIP exports, keystores, screenshots, or generated build output. Use GitHub Actions artifacts or Releases instead.
