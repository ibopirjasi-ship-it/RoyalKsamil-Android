# Royal Ksamil currently uses only Android framework APIs.
