Royal Ksamil — TWA Final Package

Finalized from the supplied Trusted Web Activity package.

Changes:
- Enlarged Royal Ksamil launcher icon for Samsung/Android
- Adaptive/maskable icon updated
- Splash screen uses the supplied Royal Ksamil logo
- Shortcut and store icons updated
- Version: 3.0.0 (versionCode 3)
- Domain remains https://royalksamil.com/
- Package remains com.royalksamil.app

For a true full-screen Trusted Web Activity, publish the included assetlinks.json at:
https://royalksamil.com/.well-known/assetlinks.json

Keep signing.keystore and its password private. Do not upload the signing key to a public repository.
